const inputCEP = document.querySelector("#inputCEP")

inputCEP.addEventListener("input", function(e) {
    var value = e.target.value
    var padraoCEP = value.replace(/\D/g, '') //Remove qualquer informação que não seja numero
                         .replace(/(\d{5})(\d)/, '$1-$2')

    e.target.value = padraoCEP;
})

async function ColetarCEP(dados) {
    //Usando a biblioteca fetch para buscar API ou Webservice e armazenar como objeto

    const cep = await fetch(`https://viacep.com.br/ws/${dados}/json/`).then(
        (Response) => Response.json()
    );
    DadosTela(cep);
}

function DadosTela(cep) {
    document.getElementById("inputLog").value = cep.logradouro
    document.getElementById("inputBairro").value = cep.bairro
    document.getElementById("inputComp").value = cep.complemento
    document.getElementById("inputCidade").value = cep.localidade
    document.getElementById("inputUF").value = cep.uf

    if (document.getElementById("inputLog") != ""){
        document.getElementById("inputLog").disabled = true;
    }
    if (document.getElementById("inputBairro") != ""){
        document.getElementById("inputBairro").disabled = true;
    }
    if (document.getElementById("inputComp") != ""){
        document.getElementById("inputComp").disabled = true;
    }
    if (document.getElementById("inputCidade") != ""){
        document.getElementById("inputCidade").disabled = true;
    }
    if (document.getElementById("inputUF") != ""){
        document.getElementById("inputUF").disabled = true;
    }
    
}


document.getElementById("btnEnviar").addEventListener("click", () =>{


    let CEP = document.getElementById("inputCEP").value
    let CEPCorrigido = CEP.replace(/[^1234567890]+/g, '')

    ColetarCEP(CEPCorrigido)

})

document.getElementById("btnLimpar").addEventListener("click", () =>{
    document.getElementById("inputLog").value = "";
    document.getElementById("inputBairro").value = "";
    document.getElementById("inputCidade").value = "";
    document.getElementById("inputComp").value = "";
    document.getElementById("inputUF").value = "";

    document.getElementById("inputLog").disabled = false;
    document.getElementById("inputBairro").disabled = false;
    document.getElementById("inputCidade").disabled = false;
    document.getElementById("inputComp").disabled = false;
    document.getElementById("inputUF").disabled = false;

    inputCEP.value = "";
})


